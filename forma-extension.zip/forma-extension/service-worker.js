"use strict";
(() => {
  // src/utils/constants.ts
  var STORAGE_KEYS = {
    PROFILE: "forma_profile",
    LEARNED_MAPPINGS: "forma_learned_mappings",
    SETTINGS: "forma_settings"
  };

  // src/core/storage/storageManager.ts
  async function getLearnedMappings() {
    const result = await chrome.storage.local.get(STORAGE_KEYS.LEARNED_MAPPINGS);
    return result[STORAGE_KEYS.LEARNED_MAPPINGS] ?? [];
  }
  async function saveLearnedMapping(mapping) {
    const existing = await getLearnedMappings();
    const idx = existing.findIndex(
      (m) => m.normalizedLabel === mapping.normalizedLabel
    );
    if (idx >= 0) {
      existing[idx] = mapping;
    } else {
      existing.push(mapping);
    }
    await chrome.storage.local.set({ [STORAGE_KEYS.LEARNED_MAPPINGS]: existing });
  }

  // src/background/service-worker.ts
  var pendingLearnCandidates = /* @__PURE__ */ new Map();
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
      case "FORMA_FILL": {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const tab = tabs[0];
          if (!tab?.id) {
            sendResponse({
              type: "FORMA_RESULT",
              payload: {
                filledCount: 0,
                skippedCount: 0,
                filledLabels: [],
                skippedLabels: []
              }
            });
            return;
          }
          chrome.tabs.sendMessage(
            tab.id,
            { type: "FORMA_FILL" },
            (response) => {
              if (chrome.runtime.lastError) {
                console.error(
                  "[Forma SW] Error sending fill command:",
                  chrome.runtime.lastError.message
                );
                sendResponse({
                  type: "FORMA_RESULT",
                  payload: {
                    filledCount: 0,
                    skippedCount: 0,
                    filledLabels: [],
                    skippedLabels: [],
                    error: "Could not reach the form page. Make sure you are on a Google Form."
                  }
                });
                return;
              }
              sendResponse(response);
            }
          );
        });
        return true;
      }
      case "FORMA_CLEAR_HIGHLIGHTS": {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const tab = tabs[0];
          if (!tab?.id) {
            sendResponse({ success: false });
            return;
          }
          chrome.tabs.sendMessage(
            tab.id,
            { type: "FORMA_CLEAR_HIGHLIGHTS" },
            (response) => {
              if (chrome.runtime.lastError) {
                console.error(
                  "[Forma SW] Error clearing highlights:",
                  chrome.runtime.lastError.message
                );
              }
              sendResponse(response ?? { success: false });
            }
          );
        });
        return true;
      }
      case "FORMA_LEARN_CANDIDATE": {
        const { normalizedLabel, rawLabel, resolvedKey } = message.payload;
        const notificationId = `forma-learn-${Date.now()}`;
        pendingLearnCandidates.set(notificationId, {
          normalizedLabel,
          resolvedKey
        });
        chrome.notifications.create(notificationId, {
          type: "basic",
          iconUrl: "assets/icon128.png",
          title: "Forma \u2014 Save Mapping?",
          message: `Save "${rawLabel}" \u2192 ${resolvedKey} for future forms?`,
          buttons: [{ title: "Yes, Save" }, { title: "Dismiss" }],
          requireInteraction: true
        });
        sendResponse({ received: true });
        return false;
      }
      case "FORMA_RESULT": {
        console.debug("[Forma SW] Auto-fill result received:", message.payload);
        return false;
      }
      default:
        return false;
    }
  });
  chrome.notifications.onButtonClicked.addListener(
    async (notificationId, buttonIndex) => {
      const candidate = pendingLearnCandidates.get(notificationId);
      if (!candidate)
        return;
      if (buttonIndex === 0) {
        await saveLearnedMapping({
          normalizedLabel: candidate.normalizedLabel,
          profileKey: candidate.resolvedKey,
          savedAt: Date.now()
        });
        console.debug(
          `[Forma SW] Learned mapping saved: "${candidate.normalizedLabel}" \u2192 "${candidate.resolvedKey}"`
        );
      }
      pendingLearnCandidates.delete(notificationId);
      chrome.notifications.clear(notificationId);
    }
  );
  chrome.notifications.onClicked.addListener((notificationId) => {
    pendingLearnCandidates.delete(notificationId);
    chrome.notifications.clear(notificationId);
  });
  console.debug("[Forma SW] Service worker loaded.");
})();
