"use strict";
(() => {
  // src/utils/constants.ts
  var STORAGE_KEYS = {
    PROFILE: "forma_profile",
    LEARNED_MAPPINGS: "forma_learned_mappings",
    SETTINGS: "forma_settings"
  };

  // src/core/storage/storageManager.ts
  async function getProfile() {
    const result = await chrome.storage.local.get(STORAGE_KEYS.PROFILE);
    return result[STORAGE_KEYS.PROFILE] ?? null;
  }
  async function saveProfile(profile) {
    await chrome.storage.local.set({ [STORAGE_KEYS.PROFILE]: profile });
  }
  async function clearAll() {
    await chrome.storage.local.remove([
      STORAGE_KEYS.PROFILE,
      STORAGE_KEYS.LEARNED_MAPPINGS,
      STORAGE_KEYS.SETTINGS
    ]);
  }

  // src/options/options.ts
  var FIELD_MAPPINGS = [
    // Name
    { id: "name-first", path: ["name", "first"], required: true },
    { id: "name-middle", path: ["name", "middle"], required: false },
    { id: "name-last", path: ["name", "last"], required: true },
    // Contact
    { id: "email-personal", path: ["contact", "email", "personal"], required: true },
    { id: "email-college", path: ["contact", "email", "college"], required: false },
    { id: "email-alternate", path: ["contact", "email", "alternate"], required: false },
    { id: "phone-country-code", path: ["contact", "phone", "countryCode"], required: false },
    { id: "phone-primary", path: ["contact", "phone", "primary"], required: true },
    { id: "phone-alternate", path: ["contact", "phone", "alternate"], required: false },
    { id: "linkedin", path: ["contact", "linkedin"], required: false },
    { id: "github", path: ["contact", "github"], required: false },
    // Personal
    { id: "gender", path: ["personal", "gender"], required: false },
    // DOB is handled manually (dob-display ↔ dob hidden picker)
    // Academic
    { id: "college", path: ["academic", "college"], required: true },
    { id: "degree", path: ["academic", "degree"], required: true },
    { id: "department", path: ["academic", "department"], required: true },
    { id: "enrollment", path: ["academic", "enrollment"], required: true },
    { id: "grad-year", path: ["academic", "gradYear"], required: true },
    { id: "cgpa", path: ["academic", "cgpa"], required: false },
    { id: "grad-percentage", path: ["academic", "graduationPercentage"], required: false },
    // 10th
    { id: "tenth-board", path: ["academic", "tenth", "board"], required: true },
    { id: "tenth-percentage", path: ["academic", "tenth", "percentage"], required: true },
    { id: "tenth-year", path: ["academic", "tenth", "passingYear"], required: true },
    // 12th
    { id: "twelfth-board", path: ["academic", "twelfth", "board"], required: true },
    { id: "twelfth-percentage", path: ["academic", "twelfth", "percentage"], required: true },
    { id: "twelfth-year", path: ["academic", "twelfth", "passingYear"], required: true },
    // PG
    { id: "pg-degree", path: ["academic", "pg", "degree"], required: false },
    { id: "pg-percentage", path: ["academic", "pg", "percentage"], required: false }
  ];
  var form = document.getElementById("profile-form");
  var btnClear = document.getElementById("btn-clear");
  var backlogCountGroup = document.getElementById("backlog-count-group");
  var backlogCountInput = document.getElementById("backlog-count");
  var toast = document.getElementById("toast");
  var toastMessage = document.getElementById("toast-message");
  var dobDisplay = document.getElementById("dob-display");
  var dobPicker = document.getElementById("dob");
  var dobCalendarBtn = document.getElementById("dob-calendar-btn");
  function getInputValue(id) {
    const el = document.getElementById(id);
    return el?.value?.trim() ?? "";
  }
  function setInputValue(id, value) {
    const el = document.getElementById(id);
    if (el)
      el.value = value;
  }
  function setNestedValue(obj, path, value) {
    let current = obj;
    for (let i = 0; i < path.length - 1; i++) {
      if (!(path[i] in current) || typeof current[path[i]] !== "object") {
        current[path[i]] = {};
      }
      current = current[path[i]];
    }
    current[path[path.length - 1]] = value;
  }
  function getNestedValue(obj, path) {
    let current = obj;
    for (const key of path) {
      if (current === null || current === void 0 || typeof current !== "object")
        return "";
      current = current[key];
    }
    return typeof current === "string" ? current : "";
  }
  function showToast(message, type = "success") {
    toastMessage.textContent = message;
    toast.className = `toast show ${type}`;
    setTimeout(() => {
      toast.classList.remove("show");
    }, 3e3);
  }
  function getSelectedBacklog() {
    const selected = document.querySelector(
      'input[name="active-backlog"]:checked'
    );
    return selected?.value ?? "";
  }
  function setSelectedBacklog(value) {
    const radio = document.querySelector(
      `input[name="active-backlog"][value="${value}"]`
    );
    if (radio)
      radio.checked = true;
  }
  function isoToDdMmYyyy(iso) {
    if (!iso || !iso.includes("-"))
      return "";
    const [year, month, day] = iso.split("-");
    return `${day}/${month}/${year}`;
  }
  function ddMmYyyyToIso(display) {
    if (!display || !display.includes("/"))
      return "";
    const parts = display.split("/");
    if (parts.length !== 3)
      return "";
    const [day, month, year] = parts;
    return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
  }
  async function loadProfile() {
    const profile = await getProfile();
    if (!profile)
      return;
    const profileObj = profile;
    for (const mapping of FIELD_MAPPINGS) {
      const value = getNestedValue(profileObj, mapping.path);
      setInputValue(mapping.id, value);
    }
    if (profile.personal.dob) {
      dobDisplay.value = isoToDdMmYyyy(profile.personal.dob);
      dobPicker.value = profile.personal.dob;
    }
    setSelectedBacklog(profile.placement.activeBacklog);
    backlogCountInput.value = profile.placement.backlogCount;
    updateBacklogVisibility();
  }
  function validate() {
    let isValid = true;
    document.querySelectorAll(".field-error").forEach((el) => {
      el.textContent = "";
    });
    document.querySelectorAll(".field-input.error").forEach((el) => {
      el.classList.remove("error");
    });
    for (const mapping of FIELD_MAPPINGS) {
      if (!mapping.required)
        continue;
      const value = getInputValue(mapping.id);
      if (!value) {
        const input = document.getElementById(mapping.id);
        const errorEl = document.getElementById(`error-${mapping.id}`);
        if (input)
          input.classList.add("error");
        if (errorEl)
          errorEl.textContent = "This field is required";
        isValid = false;
      }
    }
    const phone = getInputValue("phone-primary");
    if (phone && (phone.length !== 10 || phone.startsWith("0") || !/^\d+$/.test(phone))) {
      const input = document.getElementById("phone-primary");
      const errorEl = document.getElementById("error-phone-primary");
      if (input)
        input.classList.add("error");
      if (errorEl)
        errorEl.textContent = "Must be 10 digits, no leading 0";
      isValid = false;
    }
    return isValid;
  }
  async function handleSave(e) {
    e.preventDefault();
    if (!validate()) {
      showToast("Please fill all required fields.", "error");
      const firstError = document.querySelector(".field-input.error");
      if (firstError) {
        firstError.scrollIntoView({ behavior: "smooth", block: "center" });
      }
      return;
    }
    const profileObj = {};
    for (const mapping of FIELD_MAPPINGS) {
      setNestedValue(profileObj, mapping.path, getInputValue(mapping.id));
    }
    const dobIso = ddMmYyyyToIso(dobDisplay.value.trim());
    setNestedValue(profileObj, ["personal", "dob"], dobIso);
    setNestedValue(profileObj, ["placement", "activeBacklog"], getSelectedBacklog());
    setNestedValue(profileObj, ["placement", "backlogCount"], backlogCountInput.value || "0");
    await saveProfile(profileObj);
    showToast("Profile saved successfully! \u2713", "success");
  }
  async function handleClear() {
    const confirmed = confirm(
      "This will delete all your saved data (profile, learned mappings, and settings). Are you sure?"
    );
    if (!confirmed)
      return;
    await clearAll();
    form.reset();
    dobDisplay.value = "";
    dobPicker.value = "";
    showToast("All data cleared.", "success");
  }
  function updateBacklogVisibility() {
    const backlog = getSelectedBacklog();
    if (backlog === "Yes") {
      backlogCountGroup.style.display = "";
    } else {
      backlogCountGroup.style.display = "none";
      backlogCountInput.value = "0";
    }
  }
  form.addEventListener("submit", handleSave);
  btnClear.addEventListener("click", handleClear);
  document.querySelectorAll('input[name="active-backlog"]').forEach((radio) => {
    radio.addEventListener("change", updateBacklogVisibility);
  });
  dobCalendarBtn.addEventListener("click", () => {
    dobPicker.showPicker();
  });
  dobPicker.addEventListener("change", () => {
    const iso = dobPicker.value;
    if (iso) {
      dobDisplay.value = isoToDdMmYyyy(iso);
    }
  });
  dobDisplay.addEventListener("input", () => {
    let v = dobDisplay.value.replace(/[^0-9/]/g, "");
    if (v.length === 2 && !v.includes("/"))
      v += "/";
    if (v.length === 5 && v.indexOf("/", 3) === -1)
      v += "/";
    dobDisplay.value = v;
  });
  loadProfile();
})();
