"use strict";
(() => {
  // src/utils/constants.ts
  var STORAGE_KEYS = {
    PROFILE: "forma_profile",
    LEARNED_MAPPINGS: "forma_learned_mappings",
    SETTINGS: "forma_settings"
  };
  var DEFAULT_SETTINGS = {
    autoFillOnLoad: false,
    autoFillDelay: 500,
    fuseThreshold: 0.35,
    highlightFilled: "#f0f4ee",
    // Softest Sage
    highlightSkipped: "#fcf6ed"
    // Softest Amber
  };

  // src/core/storage/storageManager.ts
  async function getProfile() {
    const result = await chrome.storage.local.get(STORAGE_KEYS.PROFILE);
    return result[STORAGE_KEYS.PROFILE] ?? null;
  }
  async function getSettings() {
    const result = await chrome.storage.local.get(STORAGE_KEYS.SETTINGS);
    const stored = result[STORAGE_KEYS.SETTINGS] ?? {};
    return { ...DEFAULT_SETTINGS, ...stored };
  }
  async function saveSettings(settings) {
    await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: settings });
  }

  // src/popup/popup.ts
  var profileIndicator = document.getElementById("profile-indicator");
  var profileText = document.getElementById("profile-text");
  var btnAutofill = document.getElementById("btn-autofill");
  var resultsArea = document.getElementById("results-area");
  var filledCount = document.getElementById("filled-count");
  var skippedCount = document.getElementById("skipped-count");
  var btnClear = document.getElementById("btn-clear");
  var notOnForm = document.getElementById("not-on-form");
  var toggleAutofill = document.getElementById("toggle-autofill");
  var btnOptions = document.getElementById("btn-options");
  var isOnGoogleForm = false;
  var hasProfile = false;
  async function initialize() {
    const profile = await getProfile();
    hasProfile = profile !== null;
    if (hasProfile) {
      profileIndicator.classList.add("complete");
      profileText.textContent = "Profile: Complete";
    } else {
      profileIndicator.classList.add("incomplete");
      profileText.textContent = "Profile: Incomplete \u2014 click Edit Profile";
    }
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      isOnGoogleForm = tab?.url?.includes("docs.google.com/forms") ?? false;
    } catch {
      isOnGoogleForm = false;
    }
    if (!hasProfile) {
      btnAutofill.disabled = true;
      btnAutofill.title = "Set up your profile first";
    } else if (!isOnGoogleForm) {
      btnAutofill.disabled = true;
      notOnForm.classList.remove("hidden");
    } else {
      btnAutofill.disabled = false;
    }
    const settings = await getSettings();
    toggleAutofill.checked = settings.autoFillOnLoad;
  }
  btnAutofill.addEventListener("click", async () => {
    if (!hasProfile || !isOnGoogleForm)
      return;
    btnAutofill.classList.add("loading");
    btnAutofill.textContent = "Filling...";
    btnAutofill.disabled = true;
    try {
      const response = await chrome.runtime.sendMessage({ type: "FORMA_FILL" });
      if (response?.payload) {
        const result = response.payload;
        showResults(result);
      } else {
        showResults({
          filledCount: 0,
          skippedCount: 0,
          filledLabels: [],
          skippedLabels: []
        });
      }
    } catch (error) {
      console.error("[Forma Popup] Autofill error:", error);
      showResults({
        filledCount: 0,
        skippedCount: 0,
        filledLabels: [],
        skippedLabels: []
      });
    }
    btnAutofill.classList.remove("loading");
    btnAutofill.innerHTML = `
    <svg class="btn-icon" viewBox="0 0 20 20" fill="currentColor" width="18" height="18">
      <path d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z"/>
    </svg>
    Autofill This Form
  `;
    btnAutofill.disabled = false;
  });
  btnClear.addEventListener("click", async () => {
    try {
      await chrome.runtime.sendMessage({ type: "FORMA_CLEAR_HIGHLIGHTS" });
      resultsArea.classList.add("hidden");
    } catch (error) {
      console.error("[Forma Popup] Clear highlights error:", error);
    }
  });
  toggleAutofill.addEventListener("change", async () => {
    const settings = await getSettings();
    settings.autoFillOnLoad = toggleAutofill.checked;
    await saveSettings(settings);
  });
  btnOptions.addEventListener("click", (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });
  function showResults(result) {
    filledCount.textContent = String(result.filledCount);
    skippedCount.textContent = String(result.skippedCount);
    resultsArea.classList.remove("hidden");
  }
  initialize();
})();
